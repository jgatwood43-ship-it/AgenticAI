"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  agents/llm_decision_agent.py                                               ║
║  Agent 1 – LLM Decision Step                                                ║
╚══════════════════════════════════════════════════════════════════════════════╝

PURPOSE
───────
Inspect the incoming user query and emit a ROUTING decision that determines
which branch of the workflow executes next:

    • Route.RETRIEVER        → send the query through the full RAG pipeline
                               (RetrieverAgent → GraderWriterAgent → AnswerGeneratorAgent)
    • Route.ANSWER_GENERATOR → skip retrieval and answer directly from the LLM's
                               parametric knowledge

FRAMEWORKS USED IN THIS AGENT
──────────────────────────────
┌──────────┬──────────────────────────────────────────────────────────────────┐
│ ReAct    │ The agent runs a Reason → Act → Observe loop (LlamaIndex          │
│          │ ReActAgent).  It can call MCP tools to inspect database schemas   │
│          │ before making its routing decision, then emits a ROUTE token.     │
├──────────┼──────────────────────────────────────────────────────────────────┤
│ MCP      │ Two FunctionTools (mysql_query, postgres_query) give the agent    │
│          │ optional read access to the live databases via the Database-MCP   │
│          │ server (npx database-mcp).  Useful for checking whether a table   │
│          │ relevant to the query exists before committing to a route.        │
├──────────┼──────────────────────────────────────────────────────────────────┤
│ ToT      │ NOT USED in this agent.  Routing is a binary decision that does   │
│          │ not benefit from multi-branch exploration; ReAct is sufficient.   │
├──────────┼──────────────────────────────────────────────────────────────────┤
│ RAG      │ NOT USED in this agent.  This agent DECIDES whether to use RAG;  │
│          │ it does not perform retrieval itself.                              │
└──────────┴──────────────────────────────────────────────────────────────────┘

REACT LOOP DETAIL
─────────────────
  Thought  : "The question asks about X. Does the vector DB likely have relevant
              documents?  Let me check the Postgres schema."
  Action   : postgres_query("SELECT table_name FROM information_schema.tables …")
  Observe  : [table list returned]
  Thought  : "Table 'document_embeddings' exists and the query is domain-specific.
              I should route to retriever."
  Answer   : ROUTE: retriever

TERMINAL OUTPUT
───────────────
  Every ReAct Thought / Action / Observation is printed as it happens (verbose=True).
  A summary line is printed at the end showing the chosen route.
"""
from __future__ import annotations

import re

from llama_index.core.agent import ReActAgent
from llama_index.core.llms import LLM

from core.state import Route, WorkflowState
from tools.mcp_tools import ALL_MCP_TOOLS
from config.settings import settings

# ─────────────────────────────────────────────────────────────────────────────
# System prompt injected into the ReAct agent at construction time.
# The prompt constrains the LLM to output exactly one routing token after
# its reasoning so the parser below has a reliable signal to extract.
# ─────────────────────────────────────────────────────────────────────────────
_DECISION_SYSTEM_PROMPT = """\
You are a ROUTING agent in a multi-agent RAG pipeline.

Your ONLY job is to decide how to handle the user's question:

  "retriever"        → the question needs context from documents stored in the
                       vector database.  Use this route for specific, factual,
                       or domain-specific questions that require grounded evidence.
  "answer_generator" → the question is general enough to be answered from your
                       own parametric knowledge without document retrieval.

You have access to database tools (mysql_query, postgres_query).
Use them ONLY if you need to confirm whether relevant data exists in a schema.

──────────────────────────────────────────────────────────────────────────────
REACT INSTRUCTIONS
──────────────────
1. Think step by step about the nature of the query.
2. Optionally call a database tool to inspect schemas.
3. Reason about whether the vector store is likely to contain relevant chunks.
4. Output EXACTLY ONE of these two lines (nothing after it):

     ROUTE: retriever
     ROUTE: answer_generator
──────────────────────────────────────────────────────────────────────────────
"""


def _parse_route(text: str) -> Route:
    """
    Extract the routing decision token from the ReAct agent's final response.

    Searches for the pattern  ROUTE: <token>  (case-insensitive).
    Falls back to Route.RETRIEVER if no clear token is found — safer to
    over-retrieve than to miss domain-specific information.
    """
    match = re.search(r"ROUTE:\s*(retriever|answer_generator)", text, re.IGNORECASE)
    if match:
        token = match.group(1).lower()
        return Route.RETRIEVER if token == "retriever" else Route.ANSWER_GENERATOR
    # Conservative fallback: prefer retrieval over direct generation
    return Route.RETRIEVER


# ─────────────────────────────────────────────────────────────────────────────
# Agent class
# ─────────────────────────────────────────────────────────────────────────────

class LLMDecisionAgent:
    """
    Agent 1 – LLM Decision Step.

    Wraps a LlamaIndex ReActAgent configured with MCP database tools.
    Produces a single routing decision (Route enum) stored in WorkflowState.

    Frameworks
    ----------
    ReAct : Core reasoning loop.  The LLM iterates Thought → Action → Observe
            until it has enough information to emit a confident routing token.
    MCP   : mysql_query and postgres_query tools available for schema inspection.
    """

    def __init__(self, llm: LLM) -> None:
        # ── [ReAct] Build the ReActAgent with MCP tools ───────────────────────
        # ReActAgent implements the Reason+Act loop natively.
        # verbose=True causes every Thought / Action / Observation to be
        # printed to the terminal in real time — useful for debugging and
        # understanding what the agent is doing at each iteration.
        print("\n[LLMDecisionAgent] ⚙  Initialising ReActAgent (ReAct framework)…")
        print("[LLMDecisionAgent]    Tools available: mysql_query (MCP), postgres_query (MCP)")

        self._agent = ReActAgent.from_tools(
            tools=ALL_MCP_TOOLS,              # MCP-backed database tools
            llm=llm,                          # Ollama llama3.1
            max_iterations=settings.react_max_iterations,
            verbose=True,                     # prints Thought/Action/Observe to terminal
            system_prompt=_DECISION_SYSTEM_PROMPT,
        )

    # ─────────────────────────────────────────────────────────────────────────

    def run(self, state: WorkflowState) -> WorkflowState:
        """
        Execute the routing decision for the incoming query.

        ReAct flow
        ----------
        1. The LLM receives the system prompt + user query.
        2. It emits a Thought (reasoning about the query type).
        3. Optionally it calls an MCP tool (Action) and receives a result (Observation).
        4. Steps 2-3 repeat up to max_iterations.
        5. The LLM emits its final response containing the ROUTE token.

        Consumes : state.query
        Produces : state.route, state.react_trace (appended)
        """
        print("\n" + "═" * 70)
        print("[LLMDecisionAgent] ▶  STARTING — Agent 1: LLM Decision Step")
        print(f"[LLMDecisionAgent]    Framework : ReAct")
        print(f"[LLMDecisionAgent]    Tools     : MCP (mysql_query, postgres_query)")
        print(f"[LLMDecisionAgent]    ToT       : ✗  Not applicable for binary routing")
        print(f"[LLMDecisionAgent]    RAG       : ✗  Decides whether RAG is needed; does not retrieve")
        print(f"[LLMDecisionAgent]    Query     : {state.query}")
        print("─" * 70)

        # ── [ReAct] Build the prompt and start the reasoning loop ─────────────
        # The ReActAgent will now print:
        #   Thought:     <LLM reasoning text>
        #   Action:      <tool name>  (if a tool is called)
        #   Action Input: <tool arguments>
        #   Observation: <tool result>
        # ... for each iteration until it reaches a final answer.
        print("[LLMDecisionAgent] [ReAct] Starting Thought → Action → Observe loop…")

        prompt = (
            f"User question: {state.query}\n\n"
            "Decide whether to route to 'retriever' or 'answer_generator'.\n"
            "Think step by step, optionally query a database schema, then output "
            "your ROUTE decision."
        )

        # ── [MCP] Tool calls happen inside agent.chat() automatically ─────────
        # If the agent decides to call mysql_query or postgres_query, the MCP
        # server (npx database-mcp) will be invoked and the result injected
        # as an Observation into the next ReAct iteration.
        print("[LLMDecisionAgent] [MCP] MCP tools armed: mysql_query, postgres_query")
        print("[LLMDecisionAgent]       (agent will call these if it needs schema info)")

        response = self._agent.chat(prompt)
        response_text = str(response)

        # ── Parse the ROUTE token from the LLM's final response ───────────────
        route = _parse_route(response_text)
        state.route = route

        # Append the full reasoning trace to the shared state for later inspection
        state.react_trace.append(
            f"[LLMDecisionAgent][ReAct] route={route.value}\n{response_text}"
        )

        # ── Terminal summary ──────────────────────────────────────────────────
        print("─" * 70)
        print(f"[LLMDecisionAgent] ✔  COMPLETE")
        print(f"[LLMDecisionAgent]    Routing decision : {route.value.upper()}")
        if route == Route.RETRIEVER:
            print("[LLMDecisionAgent]    Next agent       : RetrieverAgent → GraderWriterAgent → AnswerGeneratorAgent")
        else:
            print("[LLMDecisionAgent]    Next agent       : AnswerGeneratorAgent (direct)")
        print("═" * 70 + "\n")

        return state
