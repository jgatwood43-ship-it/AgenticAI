"""
tools/mcp_tools.py
───────────────────
LlamaIndex FunctionTool wrappers that call the Database-MCP server
(running via `npx database-mcp`) for MySQL and Postgres queries.
These tools are handed to the ReAct agent inside each agent node.
"""
from __future__ import annotations

import json
import subprocess
from typing import Any, Dict

from llama_index.core.tools import FunctionTool

from config.settings import settings


# ── Low-level MCP helpers ─────────────────────────────────────────────────────

def _call_mcp(method: str, params: Dict[str, Any]) -> Any:
    """
    Send a JSON-RPC 2.0 request to the Database-MCP server via npx stdio transport.

    The MCP server must be reachable; this implementation spawns a short-lived
    npx process for each call (suitable for development / low-frequency queries).
    For production, keep the process alive and communicate over its stdio stream.
    """
    payload = json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    )
    result = subprocess.run(
        ["npx", "database-mcp"],
        input=payload,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError(f"MCP error: {result.stderr.strip()}")
    response = json.loads(result.stdout)
    if "error" in response:
        raise RuntimeError(f"MCP returned error: {response['error']}")
    return response.get("result")


# ── MySQL tool ────────────────────────────────────────────────────────────────

def mysql_query_tool(sql: str) -> str:
    """
    Execute a SQL query against the MySQL database at
    {host}:{port}/{db} and return the results as a JSON string.

    Parameters
    ----------
    sql : A valid MySQL SELECT (or read-only) statement.
    """
    result = _call_mcp(
        "tools/call",
        {
            "name": "mysql_query",
            "arguments": {
                "connectionString": settings.mysql_connection_string,
                "query": sql,
            },
        },
    )
    return json.dumps(result, indent=2, default=str)


def postgres_query_tool(sql: str) -> str:
    """
    Execute a SQL query against the Postgres vector DB at
    {host}:{port}/{db} and return the results as a JSON string.

    Parameters
    ----------
    sql : A valid Postgres SELECT (or read-only) statement.
    """
    result = _call_mcp(
        "tools/call",
        {
            "name": "postgres_query",
            "arguments": {
                "connectionString": settings.pg_connection_string,
                "query": sql,
            },
        },
    )
    return json.dumps(result, indent=2, default=str)


# ── LlamaIndex FunctionTool wrappers ──────────────────────────────────────────

MYSQL_TOOL = FunctionTool.from_defaults(
    fn=mysql_query_tool,
    name="mysql_query",
    description=(
        "Query the MySQL database. Use for structured relational data. "
        "Input: a valid MySQL SELECT statement."
    ),
)

POSTGRES_TOOL = FunctionTool.from_defaults(
    fn=postgres_query_tool,
    name="postgres_query",
    description=(
        "Query the Postgres database directly (non-vector SQL). "
        "Input: a valid Postgres SELECT statement."
    ),
)

ALL_MCP_TOOLS = [MYSQL_TOOL, POSTGRES_TOOL]
